#!/bin/sh
set -e

echo "[melon] installing..."
cp -a usr/* /usr/
echo "[melon] done"
