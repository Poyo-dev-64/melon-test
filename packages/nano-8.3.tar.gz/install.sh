#!/bin/sh
set -e

echo "[melon] installing..."
cp -a usr/* /
echo "[melon] done"
